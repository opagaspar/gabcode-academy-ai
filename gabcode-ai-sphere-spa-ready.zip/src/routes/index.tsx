import { createFileRoute } from "@tanstack/react-router";
import { HeroSection } from "@/components/landing/HeroSection";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GabCode Academy AI — Aprenda Programação com IA" },
      { name: "description", content: "Plataforma premium de aprendizado de programação com IA professora, editor integrado e gamificação. Tudo em português." },
      { property: "og:title", content: "GabCode Academy AI" },
      { property: "og:description", content: "Aprenda programação do zero ao avançado com IA professora em português." },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
    </div>
  );
}
