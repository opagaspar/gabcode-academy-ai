import { useState } from "react";
import { motion } from "framer-motion";
import { Music, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";

const channels = [
  { name: "Lofi Hip Hop", id: "jfKfPfyJRdk" },
  { name: "Chuva Relaxante", id: "mPZkdNFkNps" },
  { name: "Deep Focus", id: "lTRiuFIWV54" },
  { name: "Ambient", id: "S_MOd40zlYU" },
];

export function MusicPlayer() {
  const [activeChannel, setActiveChannel] = useState<number | null>(null);
  const [muted, setMuted] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Music className="w-4 h-4 text-neon-purple" />
          Foco Musical
        </h3>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => setMuted(!muted)}
        >
          {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        {channels.map((ch, i) => (
          <button
            key={ch.id}
            onClick={() => setActiveChannel(activeChannel === i ? null : i)}
            className={`px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
              activeChannel === i
                ? "bg-neon-purple/20 text-neon-purple border border-neon-purple/30"
                : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"
            }`}
          >
            {ch.name}
          </button>
        ))}
      </div>

      {activeChannel !== null && (
        <div className="rounded-xl overflow-hidden aspect-video">
          <iframe
            width="100%"
            height="100%"
            src={`https://www.youtube.com/embed/${channels[activeChannel].id}?autoplay=1&mute=${muted ? 1 : 0}`}
            allow="autoplay; encrypted-media"
            allowFullScreen
            className="border-0"
          />
        </div>
      )}

      {activeChannel === null && (
        <div className="rounded-xl bg-secondary/50 aspect-video flex items-center justify-center">
          <p className="text-sm text-muted-foreground">Escolha um canal acima</p>
        </div>
      )}
    </motion.div>
  );
}
