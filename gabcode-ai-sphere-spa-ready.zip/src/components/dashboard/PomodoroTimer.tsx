import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Play, Pause, RotateCcw, Coffee } from "lucide-react";
import { Button } from "@/components/ui/button";

const WORK_MINS = 25;
const BREAK_MINS = 5;

export function PomodoroTimer() {
  const [secondsLeft, setSecondsLeft] = useState(WORK_MINS * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [sessions, setSessions] = useState(0);

  const totalSeconds = isBreak ? BREAK_MINS * 60 : WORK_MINS * 60;
  const progress = ((totalSeconds - secondsLeft) / totalSeconds) * 100;

  const reset = useCallback(() => {
    setIsRunning(false);
    setSecondsLeft(isBreak ? BREAK_MINS * 60 : WORK_MINS * 60);
  }, [isBreak]);

  useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          setIsRunning(false);
          if (!isBreak) {
            setSessions((p) => p + 1);
            setIsBreak(true);
            return BREAK_MINS * 60;
          } else {
            setIsBreak(false);
            return WORK_MINS * 60;
          }
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isRunning, isBreak]);

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Pomodoro</h3>
        <span className="text-xs text-muted-foreground flex items-center gap-1">
          {isBreak ? <><Coffee className="w-3 h-3" /> Pausa</> : "Foco"}
        </span>
      </div>

      {/* Circular progress */}
      <div className="relative w-36 h-36 mx-auto mb-4">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" strokeWidth="4" className="text-secondary" />
          <circle
            cx="60" cy="60" r="52" fill="none"
            strokeWidth="4"
            strokeLinecap="round"
            className="text-neon-cyan"
            style={{
              stroke: isBreak ? "var(--neon-green)" : "var(--neon-cyan)",
              strokeDasharray: `${2 * Math.PI * 52}`,
              strokeDashoffset: `${2 * Math.PI * 52 * (1 - progress / 100)}`,
              transition: "stroke-dashoffset 0.5s ease",
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-mono font-bold text-foreground">
            {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-center gap-2">
        <Button variant="glass" size="icon" onClick={() => setIsRunning(!isRunning)}>
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <Button variant="glass" size="icon" onClick={reset}>
          <RotateCcw className="w-4 h-4" />
        </Button>
      </div>

      <p className="text-center text-xs text-muted-foreground mt-3">
        {sessions} sessão{sessions !== 1 ? "ões" : ""} hoje
      </p>
    </motion.div>
  );
}
